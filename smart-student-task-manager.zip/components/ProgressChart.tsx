
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

interface ProgressChartProps {
    data: { name: string; value: number; fill: string; }[];
}

export const ProgressChart: React.FC<ProgressChartProps> = ({ data }) => {
    const total = data.reduce((sum, entry) => sum + entry.value, 0);

    return (
        <div style={{ width: '100%', height: 250 }}>
            <ResponsiveContainer>
                <PieChart>
                    <Pie
                        data={data}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        innerRadius={50}
                        fill="#8884d8"
                        dataKey="value"
                        stroke="none"
                    >
                        {data.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                    </Pie>
                    <Tooltip />
                    <Legend iconType="circle" />
                    {total > 0 && 
                        <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle" className="text-3xl font-bold fill-current text-slate-700">
                            {`${Math.round((data[0].value / total) * 100)}%`}
                        </text>
                    }
                    {total === 0 &&
                        <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle" className="text-lg font-bold fill-current text-slate-500">
                            No Tasks
                        </text>
                    }
                </PieChart>
            </ResponsiveContainer>
        </div>
    );
};
