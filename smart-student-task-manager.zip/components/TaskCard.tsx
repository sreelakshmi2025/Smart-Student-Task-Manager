
import React from 'react';
import { Task, Priority, Status } from '../types';
import { Calendar, Edit, Trash2, CheckCircle, Circle } from 'lucide-react';

interface TaskCardProps {
  task: Task;
  onEdit: (task: Task) => void;
  onDelete: (taskId: string) => void;
  onToggleStatus: (taskId: string) => void;
  viewMode: 'grid' | 'list';
}

const priorityClasses = {
  [Priority.High]: 'bg-red-100 text-red-800 border-red-200',
  [Priority.Medium]: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  [Priority.Low]: 'bg-green-100 text-green-800 border-green-200',
};

const statusClasses = {
    [Status.Completed]: 'bg-green-100 text-green-800',
    [Status.Pending]: 'bg-orange-100 text-orange-800',
};

const isOverdue = (dueDate: string) => {
    return new Date(dueDate) < new Date() && new Date(dueDate).toDateString() !== new Date().toDateString();
}


export const TaskCard: React.FC<TaskCardProps> = ({ task, onEdit, onDelete, onToggleStatus, viewMode }) => {
  const overdue = isOverdue(task.dueDate) && task.status === Status.Pending;
  
  if (viewMode === 'list') {
      return (
          <div className={`flex items-center p-4 rounded-lg border transition-shadow hover:shadow-md ${task.status === Status.Completed ? 'bg-slate-50 opacity-70' : 'bg-white'}`}>
              <button onClick={() => onToggleStatus(task.id)} className="mr-4">
                  {task.status === Status.Completed ? <CheckCircle className="h-6 w-6 text-green-500"/> : <Circle className="h-6 w-6 text-slate-400"/>}
              </button>
              <div className="flex-grow">
                  <h3 className={`font-semibold ${task.status === Status.Completed ? 'line-through text-slate-500' : 'text-slate-800'}`}>{task.title}</h3>
                  <p className="text-sm text-slate-500">{task.subject}</p>
              </div>
              <div className={`text-sm flex items-center gap-2 ${overdue ? 'text-red-600 font-semibold' : 'text-slate-500'}`}>
                    <Calendar className="h-4 w-4" />
                    {new Date(task.dueDate).toLocaleDateString()}
              </div>
              <div className={`ml-4 text-xs font-semibold px-2 py-1 rounded-full ${priorityClasses[task.priority]}`}>{task.priority}</div>
              <div className="ml-4 flex items-center gap-2">
                    <button onClick={() => onEdit(task)} className="p-2 text-slate-500 hover:text-blue-600 rounded-full hover:bg-slate-100"><Edit className="h-4 w-4"/></button>
                    <button onClick={() => onDelete(task.id)} className="p-2 text-slate-500 hover:text-red-600 rounded-full hover:bg-slate-100"><Trash2 className="h-4 w-4"/></button>
              </div>
          </div>
      )
  }
  
  return (
    <div className={`p-5 rounded-2xl border flex flex-col justify-between transition-shadow hover:shadow-lg ${task.status === Status.Completed ? 'bg-slate-50 opacity-70' : 'bg-white'}`}>
      <div>
        <div className="flex justify-between items-start mb-2">
            <span className={`text-xs font-bold px-3 py-1 rounded-full ${priorityClasses[task.priority]}`}>
                {task.priority}
            </span>
            <span className={`text-xs font-bold px-3 py-1 rounded-full ${statusClasses[task.status]}`}>
                {task.status}
            </span>
        </div>
        <h3 className={`font-bold text-lg mb-1 ${task.status === Status.Completed ? 'line-through text-slate-500' : 'text-slate-800'}`}>
          {task.title}
        </h3>
        <p className="text-sm text-slate-600 mb-3">{task.subject}</p>
        <p className="text-sm text-slate-500 mb-4 h-10 overflow-hidden">{task.description}</p>
      </div>

      <div>
        <div className={`flex items-center gap-2 text-sm mb-4 ${overdue ? 'text-red-600 font-semibold' : 'text-slate-500'}`}>
          <Calendar className="h-4 w-4" />
          <span>Due: {new Date(task.dueDate).toLocaleDateString()}</span>
          {overdue && <span className="text-xs font-bold">(Overdue)</span>}
        </div>
        <div className="flex items-center justify-between border-t pt-4">
            <button onClick={() => onToggleStatus(task.id)} className="flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-green-600 transition">
                {task.status === Status.Completed ? <Circle className="h-5 w-5"/> : <CheckCircle className="h-5 w-5" />}
                {task.status === Status.Completed ? 'Mark Pending' : 'Mark Done'}
            </button>
            <div className="flex items-center gap-2">
              <button onClick={() => onEdit(task)} className="p-2 text-slate-500 hover:text-blue-600 rounded-full hover:bg-slate-100"><Edit className="h-5 w-5"/></button>
              <button onClick={() => onDelete(task.id)} className="p-2 text-slate-500 hover:text-red-600 rounded-full hover:bg-slate-100"><Trash2 className="h-5 w-5"/></button>
            </div>
        </div>
      </div>
    </div>
  );
};
