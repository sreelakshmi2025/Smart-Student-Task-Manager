
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Task, Status, Priority } from '../types';
import { TaskCard } from '../components/TaskCard';
import { TaskModal } from '../components/TaskModal';
import { ProgressChart } from '../components/ProgressChart';
import { Plus, Filter, LayoutGrid, List } from 'lucide-react';

const MOCK_TASKS: Task[] = [
    { id: '1', title: 'Complete Math Homework', description: 'Chapter 5, problems 1-20', dueDate: '2024-08-15', priority: Priority.High, subject: 'Math', status: Status.Pending },
    { id: '2', title: 'Write History Essay', description: 'Essay on the Renaissance period.', dueDate: '2024-08-20', priority: Priority.Medium, subject: 'History', status: Status.Pending },
    { id: '3', title: 'Study for Physics Test', description: 'Chapters 3 & 4 on Kinematics.', dueDate: '2024-08-10', priority: Priority.High, subject: 'Physics', status: Status.Completed },
    { id: '4', title: 'Prepare Chemistry Lab Report', description: 'Experiment #2 on Titration.', dueDate: '2024-08-18', priority: Priority.Low, subject: 'Chemistry', status: Status.Pending },
];


export const Dashboard: React.FC = () => {
    const [tasks, setTasks] = useState<Task[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingTask, setEditingTask] = useState<Task | null>(null);
    const [filterSubject, setFilterSubject] = useState<string>('All');
    const [filterStatus, setFilterStatus] = useState<Status | 'All'>('All');
    const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

    useEffect(() => {
        const storedTasks = localStorage.getItem('tasks');
        if (storedTasks) {
            setTasks(JSON.parse(storedTasks));
        } else {
            setTasks(MOCK_TASKS);
            localStorage.setItem('tasks', JSON.stringify(MOCK_TASKS));
        }
    }, []);
    
    const updateLocalStorage = useCallback((updatedTasks: Task[]) => {
        localStorage.setItem('tasks', JSON.stringify(updatedTasks));
    }, []);

    const handleSaveTask = (task: Task) => {
        let updatedTasks;
        if (tasks.some(t => t.id === task.id)) {
            updatedTasks = tasks.map(t => t.id === task.id ? task : t);
        } else {
            updatedTasks = [...tasks, { ...task, id: `task_${Date.now()}` }];
        }
        setTasks(updatedTasks);
        updateLocalStorage(updatedTasks);
        setIsModalOpen(false);
        setEditingTask(null);
    };

    const handleDeleteTask = (taskId: string) => {
        const updatedTasks = tasks.filter(t => t.id !== taskId);
        setTasks(updatedTasks);
        updateLocalStorage(updatedTasks);
    };
    
    const handleToggleStatus = (taskId: string) => {
        const updatedTasks = tasks.map(t => t.id === taskId ? { ...t, status: t.status === Status.Completed ? Status.Pending : Status.Completed } : t);
        setTasks(updatedTasks);
        updateLocalStorage(updatedTasks);
    };

    const handleEdit = (task: Task) => {
        setEditingTask(task);
        setIsModalOpen(true);
    };

    const handleAddNew = () => {
        setEditingTask(null);
        setIsModalOpen(true);
    };

    const uniqueSubjects = useMemo(() => ['All', ...Array.from(new Set(tasks.map(t => t.subject)))], [tasks]);

    const filteredTasks = useMemo(() => {
        return tasks
            .filter(task => filterSubject === 'All' || task.subject === filterSubject)
            .filter(task => filterStatus === 'All' || task.status === filterStatus)
            .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
    }, [tasks, filterSubject, filterStatus]);

    const progressData = useMemo(() => {
        const completed = tasks.filter(t => t.status === Status.Completed).length;
        const pending = tasks.length - completed;
        return [
            { name: 'Completed', value: completed, fill: '#22c55e' },
            { name: 'Pending', value: pending, fill: '#f97316' },
        ];
    }, [tasks]);

    return (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
                <div className="lg:col-span-1 bg-white p-6 rounded-2xl shadow-md">
                    <h3 className="text-xl font-bold text-slate-800 mb-4">Task Progress</h3>
                    <ProgressChart data={progressData} />
                </div>
                <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-md flex flex-col justify-center">
                   <h3 className="text-xl font-bold text-slate-800 mb-2">Summary</h3>
                   <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-blue-100 p-4 rounded-xl">
                            <h4 className="text-sm font-semibold text-blue-800">Total Tasks</h4>
                            <p className="text-3xl font-bold text-blue-900">{tasks.length}</p>
                        </div>
                        <div className="bg-green-100 p-4 rounded-xl">
                            <h4 className="text-sm font-semibold text-green-800">Completed</h4>
                            <p className="text-3xl font-bold text-green-900">{progressData[0].value}</p>
                        </div>
                        <div className="bg-orange-100 p-4 rounded-xl">
                            <h4 className="text-sm font-semibold text-orange-800">Pending</h4>
                            <p className="text-3xl font-bold text-orange-900">{progressData[1].value}</p>
                        </div>
                   </div>
                </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-md">
                <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
                    <h2 className="text-2xl font-bold text-slate-800">Your Tasks</h2>
                    <div className="flex items-center gap-2 flex-wrap">
                        <Filter className="h-5 w-5 text-slate-500" />
                        <select value={filterSubject} onChange={(e) => setFilterSubject(e.target.value)} className="bg-slate-100 border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500">
                            {uniqueSubjects.map(sub => <option key={sub} value={sub}>{sub}</option>)}
                        </select>
                        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value as Status | 'All')} className="bg-slate-100 border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-blue-500 focus:border-blue-500">
                            <option value="All">All Statuses</option>
                            <option value={Status.Pending}>Pending</option>
                            <option value={Status.Completed}>Completed</option>
                        </select>
                         <div className="flex items-center rounded-lg bg-slate-100 p-1">
                            <button onClick={() => setViewMode('grid')} className={`p-2 rounded-md ${viewMode === 'grid' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500'}`}><LayoutGrid className="h-5 w-5"/></button>
                            <button onClick={() => setViewMode('list')} className={`p-2 rounded-md ${viewMode === 'list' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500'}`}><List className="h-5 w-5"/></button>
                        </div>
                        <button onClick={handleAddNew} className="flex items-center gap-2 bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 transition transform hover:scale-105">
                            <Plus className="h-5 w-5" />
                            Add Task
                        </button>
                    </div>
                </div>

                {filteredTasks.length > 0 ? (
                    <div className={viewMode === 'grid' ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
                        {filteredTasks.map(task => (
                            <TaskCard key={task.id} task={task} onEdit={handleEdit} onDelete={handleDeleteTask} onToggleStatus={handleToggleStatus} viewMode={viewMode}/>
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-12">
                        <h3 className="text-lg font-medium text-slate-700">No tasks found.</h3>
                        <p className="text-slate-500">Try adjusting your filters or add a new task!</p>
                    </div>
                )}
            </div>

            {isModalOpen && <TaskModal task={editingTask} onSave={handleSaveTask} onClose={() => setIsModalOpen(false)} />}
        </div>
    );
};
